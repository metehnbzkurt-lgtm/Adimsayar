package com.pulse.pedometer

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("steps", MODE_PRIVATE) }
    private var refresh by mutableIntStateOf(0)
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.ACTIVITY_RECOGNITION] == true) startTracking()
    }
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { refresh++ }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val filter = IntentFilter(StepService.ACTION_STEPS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED) else registerReceiver(receiver, filter)
        setContent { PremiumScreen(
            steps = currentSteps(), goal = prefs.getInt("goal", 8000),
            weekly = history(7), monthly = history(30),
            sensorAvailable = (getSystemService(SENSOR_SERVICE) as SensorManager).getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null,
            onStart = { requestAndStart() },
            onGoal = { prefs.edit().putInt("goal", it).apply(); refresh++ }
        ) }
    }

    private fun currentSteps(): Int {
        refresh
        val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        return prefs.getInt(key, 0)
    }
    private fun history(days: Int): List<Pair<String, Int>> {
        refresh
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return (days - 1 downTo 0).map { offset ->
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -offset) }
            val key = sdf.format(cal.time)
            key to prefs.getInt(key, 0)
        }
    }
    private fun requestAndStart() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED)
            permissions.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        if (permissions.isNotEmpty()) permissionLauncher.launch(permissions.toTypedArray()) else startTracking()
    }
    private fun startTracking() {
        val intent = Intent(this, StepService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }
    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}

@Composable
fun PremiumScreen(steps: Int, goal: Int, weekly: List<Pair<String,Int>>, monthly: List<Pair<String,Int>>,
                  sensorAvailable: Boolean, onStart: () -> Unit, onGoal: (Int) -> Unit) {
    var showGoal by remember { mutableStateOf(false) }
    var goalText by remember(goal) { mutableStateOf(goal.toString()) }
    val bg = Color(0xFF0B1020)
    val panel = Color(0xFF151D32)
    val mint = Color(0xFF69E0B5)
    val progress = (steps.toFloat() / goal.coerceAtLeast(1)).coerceIn(0f, 1f)
    val distance = steps * 0.00075
    val calories = steps * 0.00004
    Surface(color = bg, modifier = Modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text("ADIM+", color = mint, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text("Bugün hareket sende.", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    }
                    Box(Modifier.size(46.dp).background(panel, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.DirectionsWalk, null, tint = mint, modifier = Modifier.size(26.dp))
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(28.dp)) {
                    Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("GÜNLÜK İLERLEME", color = Color(0xFF9AA8C2), fontSize = 11.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.height(18.dp))
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(210.dp)) {
                            CircularProgressIndicator(progress = { 1f }, modifier = Modifier.fillMaxSize(), strokeWidth = 13.dp, color = Color(0xFF29344D), trackColor = Color.Transparent)
                            CircularProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxSize(), strokeWidth = 13.dp, color = mint, trackColor = Color.Transparent)
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.DirectionsWalk, null, tint = mint, modifier = Modifier.size(27.dp))
                                Text("%,d".format(steps), color = Color.White, fontSize = 37.sp, fontWeight = FontWeight.Bold)
                                Text("ADIM", color = Color(0xFF9AA8C2), fontSize = 12.sp, letterSpacing = 2.sp)
                            }
                        }
                        Spacer(Modifier.height(17.dp))
                        Text("${(progress * 100).toInt()}% tamamlandı  •  Hedef: %,d".format(goal), color = Color(0xFFCAD4E7), fontSize = 13.sp)
                        Spacer(Modifier.height(15.dp))
                        OutlinedButton(onClick = { showGoal = true }, border = BorderStroke(1.dp, mint), colors = ButtonDefaults.outlinedButtonColors(contentColor = mint)) {
                            Icon(Icons.Default.Flag, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(7.dp)); Text("Hedefi düzenle")
                        }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("MESAFE", "%.2f km".format(distance), Icons.Default.Route, mint, Modifier.weight(1f))
                    StatCard("KALORİ", "%.0f kcal".format(calories), Icons.Default.LocalFireDepartment, Color(0xFFFFB36B), Modifier.weight(1f))
                    StatCard("HEDEF", "${(goal-steps).coerceAtLeast(0)}", Icons.Default.Flag, Color(0xFF9FAEFF), Modifier.weight(1f))
                }
            }
            item { ChartCard("SON 7 GÜN", weekly, mint) }
            item { ChartCard("SON 30 GÜN", monthly, Color(0xFF9FAEFF)) }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Sensors, null, tint = mint)
                            Spacer(Modifier.width(9.dp))
                            Text(if (sensorAvailable) "Adım sensörü hazır" else "Adım sensörü bulunamadı", color = Color.White, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Arka plan takibini başlatmak için aşağıdaki düğmeye dokun. Android pil ayarları uygulamayı durdurursa takip kesilebilir.", color = Color(0xFF9AA8C2), fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = onStart, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = mint, contentColor = bg)) {
                            Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Adım takibini başlat", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            item { Text("Adım+  •  Veriler yalnızca bu cihazda saklanır", color = Color(0xFF697792), fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
        }
    }
    if (showGoal) AlertDialog(
        onDismissRequest = { showGoal = false },
        title = { Text("Günlük hedef") },
        text = { OutlinedTextField(value = goalText, onValueChange = { goalText = it.filter(Char::isDigit).take(6) }, label = { Text("Adım sayısı") }, singleLine = true) },
        confirmButton = { TextButton(onClick = { goalText.toIntOrNull()?.takeIf { it in 500..100000 }?.let(onGoal); showGoal = false }) { Text("Kaydet") } },
        dismissButton = { TextButton(onClick = { showGoal = false }) { Text("Vazgeç") } }
    )
}

@Composable
fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF151D32)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(12.dp)) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(19.dp))
            Spacer(Modifier.height(9.dp))
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
            Text(title, color = Color(0xFF8998B4), fontSize = 9.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun ChartCard(title: String, data: List<Pair<String,Int>>, tint: Color) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF151D32)), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text(title, color = Color(0xFF9AA8C2), fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            val max = (data.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
            Row(Modifier.fillMaxWidth().height(105.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.Bottom) {
                data.forEach { (date, count) ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.BottomCenter) {
                            Box(Modifier.fillMaxWidth(0.62f).fillMaxHeight((count.toFloat()/max).coerceAtLeast(0.035f)).background(tint.copy(alpha = 0.85f), RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp)))
                        }
                        Spacer(Modifier.height(5.dp))
                        Text(date.takeLast(2), color = Color(0xFF8998B4), fontSize = 9.sp)
                    }
                }
            }
            Text("Toplam: %,d adım".format(data.sumOf { it.second }), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }
    }
}
