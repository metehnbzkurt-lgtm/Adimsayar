package com.pulse.pedometer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            val start = Intent(context, StepService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(start) else context.startService(start)
            } catch (_: Exception) { }
        }
    }
}
