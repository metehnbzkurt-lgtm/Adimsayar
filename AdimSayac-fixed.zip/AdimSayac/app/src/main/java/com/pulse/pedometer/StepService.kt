package com.pulse.pedometer

import android.app.*
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StepService : Service(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var stepSensor: Sensor? = null
    private var baseline = -1f
    private var lastDay = ""
    private val prefs by lazy { getSharedPreferences("steps", Context.MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(41, notification("Adımların kaydediliyor"))
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        lastDay = today()
        if (stepSensor != null) sensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onSensorChanged(event: SensorEvent?) {
        val total = event?.values?.firstOrNull() ?: return
        val day = today()
        if (day != lastDay) {
            baseline = total
            lastDay = day
            prefs.edit().putFloat("baseline", baseline).putString("day", day).putInt(day, 0).apply()
        }
        if (baseline < 0f) {
            val savedDay = prefs.getString("day", "")
            baseline = if (savedDay == day) prefs.getFloat("baseline", total) else total
            lastDay = day
            prefs.edit().putFloat("baseline", baseline).putString("day", day).apply()
        }
        // The hardware counter resets after a device reboot. Detect that reset
        // so yesterday's sensor baseline cannot suppress today's steps.
        if (total < baseline) {
            baseline = total
            prefs.edit().putFloat("baseline", baseline).putString("day", day).putInt(day, 0).apply()
        }
        val count = (total - baseline).toInt().coerceAtLeast(0)
        prefs.edit().putInt(day, count).putFloat("last_sensor_total", total).apply()
        sendBroadcast(Intent(ACTION_STEPS).setPackage(packageName))
        if (count > 0 && count % 100 == 0) updateNotification(count)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        super.onDestroy()
    }

    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("step_tracking", "Adım takibi", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun notification(text: String): Notification =
        NotificationCompat.Builder(this, "step_tracking")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Adım+").setContentText(text)
            .setOngoing(true).setOnlyAlertOnce(true).build()
    private fun updateNotification(count: Int) {
        getSystemService(NotificationManager::class.java).notify(41, notification("$count adım tamamlandı"))
    }
    companion object { const val ACTION_STEPS = "com.pulse.pedometer.STEPS_UPDATED" }
}
