# Adım+ — Android adım sayar

Premium koyu arayüzlü, Kotlin/Jetpack Compose tabanlı Android adım sayar.

## Derleme
GitHub'a bu klasörün içeriğini yükleyin (`.github` klasörü dahil). Her yüklemede **Android APK** iş akışı kendiliğinden çalışır; `Actions` sekmesinden `Run workflow` ile elle de başlatılabilir. Başarılı derlemeden sonra `AdimPlus-release` artifact'inden imzalı APK'yı indirin.

APK, depodaki `app/adim.keystore` ile sabit anahtarla imzalanır; böylece yeni sürümler telefondaki eskisinin üstüne veri kaybı olmadan güncellenir. Anahtarı ve parolasını herkese açık depolarda paylaşmayın (depoyu özel tutun).

Bu depo bilerek `gradlew` gerektirmez; GitHub Actions Gradle 8.9'u kurup derler.

## Gereksinimler
- Android Studio / Android SDK 35 (yerel derleme için)
- JDK 17
- Android 8.0+ (API 26+)
- Cihazda donanımsal `TYPE_STEP_COUNTER` sensörü

## İlk kullanım
1. Uygulamayı açın.
2. Fiziksel aktivite izni ve Android 13+ bildirim iznini verin.
3. **Adım takibini başlat** düğmesine basın.
4. İsterseniz günlük hedefi düzenleyin.

## Teknik notlar
- Adımlar Android'in donanımsal step-counter sensöründen okunur.
- Takip, kalıcı bildirimli `health` foreground service ile sürdürülür.
- Günlük sayaç, sensörün yeniden başlatma sonrası toplam değerinden günlük başlangıç değeri çıkarılarak hesaplanır.
- Mesafe (75 cm/adım) ve kalori (0,04 kcal/adım) tahminidir; profil/tempo bilgisiyle kişiselleştirilmemiştir.
- Veriler cihazdaki SharedPreferences içinde tutulur.

## Sınırlamalar / cihaz uyumluluğu
- Sensör yoksa uygulama gerçek adım sayamaz.
- Üretici pil yönetimi servisi durdurabilir. Uygulamayı pil optimizasyonundan muaf tutmak gerekebilir.
- Android'in sürüm ve üretici kısıtlamaları nedeniyle yeniden başlatma sonrası otomatik servis başlatma her cihazda garanti değildir; uygulamayı bir kez açıp takibi başlatın.
- Bu ilk sürümde veriler cihazda yereldir; bulut senkronizasyonu yoktur.
